<?php //open syntax

phpinfo();

//close
?>