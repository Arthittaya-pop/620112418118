<?php

echo $_POST['user'];
echo $_POST['pass'];